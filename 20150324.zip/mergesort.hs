mergesort :: [Int] -> [Int]
mergesort [] = []
mergesort [a] = [a]
mergesort a = merge (mergesort (take (div (length a) 2) a)) (mergesort (drop (div (length a) 2) a))
			  
merge :: [Int] -> [Int] -> [Int]
merge [] ys = ys
merge xs [] = xs
merge (x:xs) (y:ys) = if (x <= y)
            then x : merge xs (y:ys)
			else y : merge (x:xs) ys
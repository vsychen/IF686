sumPairs :: [Int] -> [Int] -> [Int]
sumPairs x y | (null x || null y) = []
             | otherwise = ((head x) + (head y)) : sumPairs (tail x) (tail y)
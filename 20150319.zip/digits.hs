digits :: String -> String
digits x | x == [] = []
         | ((head x) >= '0' && (head x) <= '9') = [(head x)] ++ digits (tail x)
         | otherwise = digits (tail x)
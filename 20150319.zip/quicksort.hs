quicksort :: [Int] -> [Int]
quicksort x | x == [] = []
            | otherwise = quicksort [y | y <- (tail x), y < (head x)] ++ [head x] ++ quicksort [y | y <- (tail x), y >= (head x)]
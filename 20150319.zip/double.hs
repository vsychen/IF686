double :: [Int] -> [Int]
double [] = []
double x = (2 * (head x)) : double (tail x)
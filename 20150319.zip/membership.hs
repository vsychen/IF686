membership :: [Int] -> Int -> Bool
membership l x | l == [] = False
               | (head l) == x = True
               | otherwise = membership (tail l) x
